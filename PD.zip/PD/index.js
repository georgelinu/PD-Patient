const { google } = require('googleapis');
const express = require('express')
const axios = require('axios')
var request = require('request');
var fs = require('fs');
var http = require('http');
var https = require('https');
var privateKey  = fs.readFileSync('selfsigned.key', 'utf8');
var certificate = fs.readFileSync('selfsigned.crt', 'utf8');

var credentials = {key: privateKey, cert: certificate};

// -----------------------------------------   Yahoo   -------------------------------------------------------------------------------------------------------

const clientID_yahoo = 'xxxxxxxxxxx'
const clientSecret_yahoo = 'xxxxxxxxxxx'
const redirect_uri_yahoo = "https://localhost:8080/auth/yahoo/callback";

// -----------------------------------------   github ID   -------------------------------------------------------------------------------------------------------
const clientID_github = 'xxxxxxxxxxx'
const clientSecret_github = 'xxxxxxxxxxx'

// -----------------------------------   Google ID   -------------------------------------------------------------------------------------------------------------
const CLIENT_ID = "xxxxxxxxxxx";
const REDIRECT_URL = "https://localhost:8080/auth/google/callback";
const CLIENT_SECRET = "xxxxxxxxxxx";
// ---------------------------------------------------------------------------------------------------------------------------------------------------------------


var OAuth = require('OAuth');
var encoded = new Buffer(clientID_yahoo+":"+clientSecret_yahoo).toString('base64')
var authHeader = "Basic " + encoded;

var oauth2 = new OAuth.OAuth2(
  clientID_yahoo,
  clientSecret_yahoo,
  'https://api.login.yahoo.com/',
  'oauth2/request_auth',
  'oauth2/get_token',
  { Authorization: "Basic " + authHeader}
);


const app = express()
app.set('view engine', 'ejs');
app.set('views','./views');
app.use(express.static("public"));

// ------------------------------   Creating Connection with the Db   -------------------------------------------------------------------------------------------

var mysql = require('mysql');
var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'pd'
})
// --------------------------------------------------------------------------------------------------------------------------------------------------


var access_token = "";
// --------------------------------------------------------------------------------------------------------------------------------------------------


const oAuth2Client = new google.auth.OAuth2(CLIENT_ID, CLIENT_SECRET, REDIRECT_URL)


// -----------------------------------   Google ID   -------------------------------------------------------------------------------------------------------------

let role;
let email_id;
let patientdetails=[]
let displaydata={
    userid:Number,
    emailid:String,
    userName:String
}


app.get('/', function(req, res) {
    res.render('pages/index',{failed:false});
});

//--------------------------    github    ------------------------------------------------------------------------------------------------------------------------

app.get('/github', function(req,res){
    const url="https://github.com/login/oauth/authorize?client_id="+clientID_github;
    res.redirect(url);
});

app.get('/github/callback', (req, res) => {
    // The req.query object has the query params that were sent to this route.
    const requestToken = req.query.code
    
    axios({
      method: 'post',
      url: `https://github.com/login/oauth/access_token?client_id=${clientID_github}&client_secret=${clientSecret_github}&code=${requestToken}`,
      headers: {
           accept: 'application/json'
      }
    }).then((response) => {
      access_token = response.data.access_token
      res.redirect('/github_success');
    })
})
  
app.get('/github_success', function(req, res) {
  
    axios({
      method: 'get',
      url: `https://api.github.com/user`,
      headers: {
        Authorization: 'token ' + access_token
      }
    }).then((response) => {
        email_id=response.data.email;
        checkValidity('github',res,1);
    })
});

//--------------------------------------------------------------------------------------------------------------------------------------------------

//--------------------------    google    ------------------------------------------------------------------------------------------------------------------------


app.get('/google', function(req,res){
    role=1;
    // Generate an OAuth URL and redirect there
    const url = oAuth2Client.generateAuthUrl({
        access_type: 'offline',
        scope: 'https://www.googleapis.com/auth/gmail.readonly'
    });
    res.redirect(url);
});


app.get('/auth/google/callback', function (req, res) {
    const code = req.query.code
    if (code) {
        // Get an access token based on our OAuth code
        oAuth2Client.getToken(code, function (err, tokens) {
            if (err) {
                console.log('Error authenticating')
                console.log(err);
            } else {
                oAuth2Client.setCredentials(tokens);
                res.redirect('/google_success')
            }
        });
    }
});


app.get('/google_success', function(req, res) {

    const gmail = google.gmail({ version: 'v1', auth: oAuth2Client });
        gmail.users.getProfile({
            userId: 'me',
        }, (err, response) => {
            if (err) return console.log('The API returned an error: ' + err);
            email_id=response.data.emailAddress;
            checkValidity('google',res,2);
        });
});




// --------------------------------------------------------------------------------------------------------------------------------------------------

function checkValidity(method,res,roleId)
{
    connection.query("SELECT * from user where email='"+email_id+"' and Role_IDrole="+roleId, function (err, rows, fields) {
        if (err) {
            return false;
        }
        if (rows && rows[0]){
            displaydata.emailid=rows[0].email;
            displaydata.userid=rows[0].userID;
            displaydata.userName=rows[0].username;
            if(roleId==1)
            {
                res.render('pages/success',{ userData: [] , loginMethod: method , logindetail: displaydata });
            }
            else {
                selectPatient(method,res);
            }
        }
        else
            res.render('pages/index',{failed:true});
    })
    
}



// -----------------------------   Select Codes for output   -------------------------------------------------------------------------------------------------------



function selectPatient(method,res)
{
    let sqlall="SELECT * FROM `user` WHERE Role_IDrole=1";
    connection.query(sqlall, function (err, rows, fields) {
        if (err) {
            console.log("err...",err);
            return false;
        }
        else{
            rows.forEach((row,index) => {
                patientdetails[index]={};
                patientdetails[index].id=index+1;
                patientdetails[index].userID=row.userID;
                patientdetails[index].userName=row.username;
                patientdetails[index].userEmail=row.email;
                patientdetails[index].role=row.Role_IDrole;
            });
            selecttherapyname(method,res)
        }

    })
}

function selecttherapyname(method,res) {

    patientdetails.forEach((patient,index) => {
        let sql="select name, Dosage from therapy_list WHERE medicine_IDmedicine=(SELECT TherapyList_IDtherapylist FROM therapy WHERE User_IDpatient = "+patient.userID+")";
        connection.query(sql, function (err, rows, fields) {
            
            if (err) {
                return false;
            }
            if (rows){
                    patient.name=rows[0].name;
                    patient.Dosage=rows[0].Dosage;
            }
            
        })
    });
    selectmedicine(method,res)
}

// --------------------------------------------------------------------------------------------------------------------------------------------------



function selectmedicine(method,res)
{
    patientdetails.forEach((patient,index) => {
        let sql="select name from medicine WHERE medicineID=(SELECT User_IDmed FROM therapy WHERE User_IDpatient = "+patient.userID+")";
        connection.query(sql, function (err, rows, fields) {
            if (err) {
                return false;
            }
            if (rows){
                patient.medicine=rows[0].name;
            }
        })
    })
    selectdatetime(method,res) 
}

// --------------------------------------------------------------------------------------------------------------------------------------------------

function selectdatetime(method,res)
{
    patientdetails.forEach((patient,index) => {
        connection.query("select dateTime from test WHERE Therapy_IDtherapy=(SELECT therapyID FROM therapy WHERE User_IDpatient = "+patient.userID+")", function (err, rows, fields) {
        
            if (err) {
                return false;
            }
            if (rows){
                patient.dateandtime=rows[0].dateTime;
            }
        })
    })
    selecttestresult(method,res)
}

// --------------------------------------------------------------------------------------------------------------------------------------------------

function selecttestresult(method,res)
{
    var rowvalue;
    patientdetails.forEach((patient,index) => {
        let sql="select DataURL from test_session WHERE Test_IDtest=(SELECT testID FROM test WHERE Therapy_IDtherapy = (SELECT therapyID FROM therapy WHERE User_IDpatient="+patient.userID+"))";
        connection.query(sql, function (err, rows, fields) {

            if (err) {
                return false;
            }
            if (rows){
                patient.data=[];
                for(let row of rows){
                    patient.data.push(row.DataURL.split('/')[1]);
                }
                if(index==patientdetails.length-1){
                    res.render('pages/success',{ userData: patientdetails , loginMethod: method , logindetail: displaydata });
                }
            }
        })
    });
}



// -----------------------------   Select Code End   -------------------------------------------------------------------------------------------------------


    app.get('/logout', function(req, res){
        // req.history.forward();
        // access_token = "";
        res.redirect('/');
    });


// -----------------------------   download a file   -------------------------------------------------------------------------------------------------------

    app.get('/download',function(req,res){
        let downl=req.query.data;
        res.download(downl);
    });
    
// -----------------------------   yahoo  -----------------------------------------------------------------------------------------------------------

app.get('/yahoo', function(req,res){
    const url="https://api.login.yahoo.com/oauth2/request_auth?client_id="+clientID_yahoo+"&redirect_uri="+redirect_uri_yahoo+"&response_type=code&language=en-us"
    res.redirect(url);
});

app.get('/auth/yahoo/callback', function (req, res) {  

    var code = req.query.code;
    oauth2.getOAuthAccessToken(
        code,
        {
            'grant_type': 'authorization_code',
            'redirect_uri': 'oob'
        },
        function(e, access_token, refresh_token, results) {
          access_token_yahoo = access_token;
          refresh_token_yahoo = refresh_token;
          res.redirect('/yahoo_success');
        });
    })  


app.get('/yahoo_success', function(req, res) {
    const url="https://api.login.yahoo.com/openid/v1/userinfo";
    request.post(
        {
        url:url,
        headers: {
            'Authorization': 'Bearer '+access_token_yahoo
        }
        },
      function(error, response, body){
        obj = JSON.parse(body);
        email_id=obj.email;
        checkValidity('yahoo',res,3);

    });

});

//-------------------------- Port ---------------------------------------------------------------------------------------------------------------

var httpServer = http.createServer(app);
var httpsServer = https.createServer(credentials, app);

httpsServer.listen(8080);

// ---------------------------------------------------------------------------------------------------------------------------------------------------
